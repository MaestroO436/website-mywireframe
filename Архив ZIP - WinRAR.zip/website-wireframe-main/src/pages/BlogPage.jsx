import { useNavigation } from '../router/navigation';
import { posts } from '../data/content';

export default function BlogPage() {
  const { go } = useNavigation();

  return (
    <main className="page">
      <section className="section">
        <h1 className="section-title">Блог</h1>
        <p className="section-subtitle">Статьи о разработке, дизайне и продуктах.</p>

        <div className="grid grid-3">
          {posts.map((post) => (
            <article key={post.title} className="card">
              <div className="card-tag">{post.tag}</div>
              <h3 className="card-title">{post.title}</h3>
              <p className="card-text">{post.excerpt}</p>
              <div className="card-meta">{post.date}</div>
            </article>
          ))}
        </div>
      </section>

      <section className="section cta">
        <h2>Хотите стать героем нашего блога?</h2>
        <p>Расскажите о проекте — напишем кейс вместе.</p>
        <button className="btn btn-primary" onClick={() => go('contacts')}>
          Связаться с нами
        </button>
      </section>
    </main>
  );
}